import { test, expect } from '@playwright/test';

test.describe('Login Functionality', () => {

  test.beforeEach(async ({ page }) => {

    
    await page.goto('/');

    
    await page.getByRole('button', { name: /Sign In/i }).click();

    
    await page.waitForLoadState('networkidle');

  });

  test('TC_001 - Verify Login page loads successfully', async ({ page }) => {

    await expect(page.locator('input[type="email"]')).toBeVisible();

    await expect(
      page.getByRole('button', { name: /^Continue$/ })
    ).toBeVisible();

    await expect(
      page.getByRole('button', { name: /Continue with Google/i })
    ).toBeVisible();

  });

  test('TC_002 - Verify empty email validation', async ({ page }) => {

    await page.getByRole('button', { name: /^Continue$/ }).click();

    await expect(
      page.getByText(/required/i)
    ).toBeVisible();

  });

  test('TC_003 - Verify invalid email format', async ({ page }) => {

    await page.locator('input[type="email"]').fill('sanjayg@mail.com');

    await page.getByRole('button', { name: /^Continue$/ }).click();

   
    await expect(
      page.getByText(/valid email/i)
    ).toBeVisible();

  });

  test('TC_004 - Verify new email redirects to Signup page', async ({ page }) => {

    const email = `sanjay${Date.now()}@gmail.com`;

    await page.locator('input[type="email"]').fill(email);

    await page.getByRole('button', { name: /^Continue$/ }).click();

    await page.waitForLoadState('networkidle');

    await expect(
      page.getByRole('button', { name: /Sign Up/i })
    ).toBeVisible();

  });

});