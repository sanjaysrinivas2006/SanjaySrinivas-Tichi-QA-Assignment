import { test, expect } from '@playwright/test';

test.describe('Signup Functionality', () => {

  test.beforeEach(async ({ page }) => {

  
    await page.goto('/');

    
    await page.getByRole('button', { name: /Sign In/i }).click();

    await page.waitForLoadState('networkidle');

    const email = `user${Date.now()}@gmail.com`;

    await page.locator('input[type="email"]').fill(email);

    await page.getByRole('button', { name: /^Continue$/ }).click();

   
    await page.waitForLoadState('networkidle');

  });

  test('TC_SIGNUP_001 - Verify Signup page UI', async ({ page }) => {

    
    await expect(page.getByText(/First Name/i)).toBeVisible();

    await expect(page.getByText(/Last Name/i)).toBeVisible();

    await expect(page.getByText(/Mobile Number/i)).toBeVisible();

   
    await expect(page.getByText(/Email Address/i)).toBeVisible();

    await expect(page.getByText(/^Password/i)).toBeVisible();

    await expect(page.getByText(/Confirm Password/i)).toBeVisible();

    await expect(
      page.locator('input[type="checkbox"]')
    ).toBeVisible();

    await expect(
      page.getByRole('button', { name: /Sign Up/i })
    ).toBeVisible();

  });

});