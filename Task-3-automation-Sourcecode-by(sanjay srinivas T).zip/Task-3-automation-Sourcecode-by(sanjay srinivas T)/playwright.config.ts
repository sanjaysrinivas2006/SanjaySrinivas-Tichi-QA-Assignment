import { defineConfig, devices } from '@playwright/test';

export default defineConfig({

  testDir: './tests',

  timeout: 60 * 1000,

  expect: {
    timeout: 5000,
  },

  fullyParallel: false,

  forbidOnly: !!process.env.CI,

  retries: process.env.CI ? 2 : 0,

  workers: 1,

  reporter: [
    ['list'],
    ['html', { open: 'on-failure' }]
  ],

  use: {
    baseURL: 'https://tichi-app-webapp-stage.web.app',

    headless: true,

    viewport: {
      width: 1366,
      height: 768,
    },

    actionTimeout: 10000,

    navigationTimeout: 60000,

    screenshot: 'only-on-failure',

    video: 'retain-on-failure',

    trace: 'retain-on-failure',
  },

  projects: [
    {
      name: 'chromium',
      use: {
        ...devices['Desktop Chrome'],
      },
    },
  ],

});